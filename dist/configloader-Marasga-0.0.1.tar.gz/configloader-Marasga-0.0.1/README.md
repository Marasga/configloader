# configlaoder Package

This is a simple config loader package. 
It is based on the idea of saving configuration file for
python program in a json and loading it into an object.
You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.